EE219 Project 5

Winter 2018

Teammembers:
Fangyao Liu----UCLA ECE Graduate student
	       UID:204945018
	       Email:fangyao@okstate.edu
Xuan Hu    ----UCLA ECE Graduate student
	       UID:505031796
	       Email:x1310317@gmail.com
YanZhe Xu  ----UCLA ECE Graduate student
	       UID:404946757
	       Email:xuyanzhesjtu@g.ucla.edu
Zhechen Xu ----UCLA ECE Graduate student
	       UID:805030074
	       Email:xzhechen@ucla.edu

Introduction:  A useful practice in social network analysis is to predict future popularity of a subject or event. Twitter, with its public discussion model, is a good platform to perform such analysis. With Twitter's topic structure in mind, the problem can be stated as: knowing current (and previous) tweet activity for a hashtag, can we predict its tweet activity in the future? More specically, can we predict if it will become more popular and if so by how much? In this project, we will try to formulate and solve an
instance of such problems.

IMPLEMENTATION
    Environment:
        python 2.7
    Dependencies:
	a.sklearn v0.19.1
	b.matplotlib v2.1.0
	c.numpy v1.13.3

Usage:
$python quesion1.1.py
$python quesion1.2.py
$python quesion1.3.py
$python 1.4.py
$python quesion1.5.py
$python quesion2.py
$python quesion3a.py
$python part3b.py
